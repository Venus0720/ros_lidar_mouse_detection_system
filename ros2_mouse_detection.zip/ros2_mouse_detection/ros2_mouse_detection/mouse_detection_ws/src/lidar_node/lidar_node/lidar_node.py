import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2, PointField
from std_msgs.msg import Header
import numpy as np
import struct
from rplidar import RPLidar  # Import the RPLIDAR SDK

class LidarNode(Node):
    def __init__(self):
        super().__init__('lidar_node')
        self.publisher = self.create_publisher(PointCloud2, 'lidar_data', 10)

        # Initialize RPLIDAR
        self.lidar = None
        self.initialize_lidar()

        # Start a timer to read and publish LiDAR data
        self.timer = self.create_timer(0.1, self.read_and_publish_lidar_data)  # 10 Hz

    def initialize_lidar(self):
        """
        Initialize the RPLIDAR sensor.
        """
        try:
            self.lidar = RPLidar('/dev/ttyUSB0')  # Use /dev/ttyUSB0
            self.get_logger().info("RPLIDAR initialized successfully")
        except Exception as e:
            self.get_logger().error(f"Failed to initialize RPLIDAR: {e}")
            self.lidar = None

    def read_and_publish_lidar_data(self):
        """
        Read data from the LiDAR sensor, convert it to PointCloud2, and publish it.
        """
        if self.lidar is None:
            self.get_logger().warn("LiDAR sensor is not initialized. Attempting to reconnect...")
            self.initialize_lidar()
            return

        try:
            # Fetch raw LiDAR data
            raw_data = self.get_lidar_data()

            if not raw_data:
                self.get_logger().warn("No LiDAR data received")
                return

            # Convert raw data to PointCloud2
            point_cloud_msg = self.create_pointcloud2(raw_data)

            # Publish to ROS 2
            self.publisher.publish(point_cloud_msg)
            self.get_logger().info('Published PointCloud to ROS 2')

        except Exception as e:
            self.get_logger().error(f"Failed to read or publish LiDAR data: {e}")

    def get_lidar_data(self):
        """
        Fetch raw data from the RPLIDAR sensor.
        Returns a list of points in the format [x, y, z, intensity].
        """
        points = []
        try:
            # Fetch data from the LiDAR sensor
            for scan in self.lidar.iter_scans():
                self.get_logger().info(f"Raw scan data: {scan}")
                for quality, angle, distance in scan:
                    x = distance * np.cos(np.radians(angle))
                    y = distance * np.sin(np.radians(angle))
                    z = 0.0  # 2D LiDAR
                    intensity = quality  # Use quality as intensity
                    points.append([x, y, z, intensity])
                break  # Process only one scan
        except Exception as e:
            self.get_logger().error(f"Failed to fetch LiDAR data: {e}")
        return points

    def create_pointcloud2(self, points):
        """
        Convert a list of points to a ROS 2 PointCloud2 message.
        """
        msg = PointCloud2()
        msg.header = Header()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = "lidar_frame"

        # Define the fields (x, y, z, intensity)
        msg.fields = [
            PointField(name="x", offset=0, datatype=PointField.FLOAT32, count=1),
            PointField(name="y", offset=4, datatype=PointField.FLOAT32, count=1),
            PointField(name="z", offset=8, datatype=PointField.FLOAT32, count=1),
            PointField(name="intensity", offset=12, datatype=PointField.FLOAT32, count=1),
        ]

        # Set the point cloud properties
        msg.height = 1
        msg.width = len(points)
        msg.is_bigendian = False
        msg.point_step = 16  # 4 fields * 4 bytes each
        msg.row_step = msg.point_step * msg.width
        msg.is_dense = True

        # Pack the points into the data buffer
        msg.data = []
        for point in points:
            msg.data.extend(struct.pack('ffff', point[0], point[1], point[2], point[3]))

        return msg

    def destroy_node(self):
        """
        Clean up the LiDAR sensor when the node is destroyed.
        """
        if self.lidar is not None:
            self.lidar.stop()
            self.lidar.disconnect()
            self.get_logger().info("RPLIDAR disconnected")
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = LidarNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
