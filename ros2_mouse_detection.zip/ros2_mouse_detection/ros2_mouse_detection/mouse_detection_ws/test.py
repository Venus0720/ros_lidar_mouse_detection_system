import sys
try:
    from unitree_lidar_ros2 import UniLidar  # Import the UniLidar SDK
    print("UniLidar SDK imported successfully!")
except ImportError as e:
    print(f"Error importing UniLidar SDK: {e}")
    sys.exit(1)

# Rest of your script...
