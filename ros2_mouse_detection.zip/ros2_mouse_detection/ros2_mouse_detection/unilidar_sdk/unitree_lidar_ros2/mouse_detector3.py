import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2
import sensor_msgs_py.point_cloud2 as pc2
import numpy as np
from datetime import datetime, timedelta
from sklearn.cluster import DBSCAN

class UniLidarSubscriber(Node):

    def __init__(self):
        super().__init__('unilidar_subscriber')
        self.subscription = self.create_subscription(
            PointCloud2,
            '/unilidar/cloud',
            self.cloud_callback,
            10)
        self.subscription  # prevent unused variable warning
        
        self.last_minute = datetime.now().replace(second=0, microsecond=0)
        self.mouse_count = 0
        self.previous_points = None
        self.total_points_processed = 0
        self.frames_processed = 0
        self.potential_mouse = False
        self.mouse_tracking_time = None
        self.mouse_disappeared_time = None
        
        # 新增：用於跟蹤所有符合老鼠尺寸的物體
        self.tracked_objects = {}
        self.object_id_counter = 0

    def cloud_callback(self, msg):
        current_time = datetime.now()
        
        try:
            pc = pc2.read_points(msg, field_names=("x", "y", "z", "intensity"), skip_nans=True)
            np_points = np.array(list(pc))
            xyz = np.array([np_points['x'], np_points['y'], np_points['z']]).T
            
            self.total_points_processed += xyz.shape[0]
            self.frames_processed += 1

            if self.previous_points is not None and xyz.shape == self.previous_points.shape:
                diff = np.abs(xyz - self.previous_points)
                moving_points = np.sum(diff > 0.05, axis=1)  # 5cm threshold
                
                if np.sum(moving_points) > 50:  # Minimum 50 moving points
                    moving_xyz = xyz[moving_points > 0]
                    
                    # Using DBSCAN for spatial clustering
                    clustering = DBSCAN(eps=0.1, min_samples=10).fit(moving_xyz)
                    labels = clustering.labels_
                    
                    # 用於存儲當前幀檢測到的物體
                    current_objects = {}
                    
                    # Process each cluster
                    for label in set(labels):
                        if label == -1:  # Skip noise
                            continue
                        
                        cluster_points = moving_xyz[labels == label]
                        size = np.max(cluster_points, axis=0) - np.min(cluster_points, axis=0)
                        center = np.mean(cluster_points, axis=0)
                        
                        # 檢測符合老鼠尺寸的物體
                        if 0.05 < np.max(size) < 0.2:  # Assume mouse size between 5cm and 20cm
                            object_id = self.find_nearest_object(center)
                            if object_id is None:
                                object_id = self.object_id_counter
                                self.object_id_counter += 1
                            
                            current_objects[object_id] = {
                                'center': center,
                                'size': size,
                                'last_seen': current_time
                            }
                            
                            self.get_logger().info(f'📊 檢測到符合老鼠尺寸的物體 (ID: {object_id}):')
                            self.get_logger().info(f'   - 點數: {cluster_points.shape[0]}')
                            self.get_logger().info(f'   - 尺寸 (m): {size}')
                            self.get_logger().info(f'   - 位置 (x,y,z): {center}')
                            
                            # 原有的老鼠檢測邏輯
                            if not self.potential_mouse:
                                self.potential_mouse = True
                                self.mouse_tracking_time = current_time
                                self.get_logger().info('潛在老鼠檢測!')
                        elif self.potential_mouse:
                            if (current_time - self.mouse_tracking_time).total_seconds() > 3:
                                if self.mouse_disappeared_time is None:
                                    self.mouse_disappeared_time = current_time
                            elif self.mouse_disappeared_time is not None:
                                if (current_time - self.mouse_disappeared_time).total_seconds() > 5:
                                    self.mouse_count += 1
                                    self.get_logger().info(f'🐭 確認老鼠! 總計: {self.mouse_count}')
                                    self.potential_mouse = False
                                    self.mouse_tracking_time = None
                                    self.mouse_disappeared_time = None
                            else:
                                self.mouse_disappeared_time = None
                    
                    # 更新跟蹤的物體
                    self.update_tracked_objects(current_objects, current_time)

            self.previous_points = xyz

            if current_time - self.last_minute >= timedelta(minutes=1):
                avg_points_per_frame = self.total_points_processed / self.frames_processed if self.frames_processed > 0 else 0
                self.get_logger().info(f'⏰ 每分鐘報告:')
                self.get_logger().info(f'   - 過去一分鐘檢測到 {self.mouse_count} 隻老鼠')
                self.get_logger().info(f'   - 處理 {self.frames_processed} 幀數據')
                self.get_logger().info(f'   - 平均每幀 {avg_points_per_frame:.2f} 個點')
                self.get_logger().info(f'   - 當前跟蹤物體數量: {len(self.tracked_objects)}')
                self.mouse_count = 0
                self.total_points_processed = 0
                self.frames_processed = 0
                self.last_minute = current_time.replace(second=0, microsecond=0)

        except Exception as e:
            self.get_logger().error(f'處理點雲數據時出錯: {str(e)}')

    def find_nearest_object(self, center, max_distance=0.2):
        for obj_id, obj_data in self.tracked_objects.items():
            distance = np.linalg.norm(obj_data['center'] - center)
            if distance < max_distance:
                return obj_id
        return None

    def update_tracked_objects(self, current_objects, current_time):
        # 更新現有物體
        for obj_id, obj_data in current_objects.items():
            if obj_id in self.tracked_objects:
                self.tracked_objects[obj_id].update(obj_data)
            else:
                self.tracked_objects[obj_id] = obj_data
                self.tracked_objects[obj_id]['first_seen'] = current_time

        # 移除長時間未檢測到的物體
        objects_to_remove = []
        for obj_id, obj_data in self.tracked_objects.items():
            if obj_id not in current_objects:
                time_since_last_seen = (current_time - obj_data['last_seen']).total_seconds()
                if time_since_last_seen > 5:  # 如果5秒內沒有再次檢測到，則移除
                    objects_to_remove.append(obj_id)
                    tracking_duration = (obj_data['last_seen'] - obj_data['first_seen']).total_seconds()
                    self.get_logger().info(f'物體 (ID: {obj_id}) 消失，總跟蹤時間: {tracking_duration:.2f} 秒')

        for obj_id in objects_to_remove:
            del self.tracked_objects[obj_id]

def main(args=None):
    rclpy.init(args=args)
    unilidar_subscriber = UniLidarSubscriber()
    rclpy.spin(unilidar_subscriber)
    unilidar_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
