#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2, PointField
import paho.mqtt.client as mqtt
import json
import base64

class MQTTBridgeNode(Node):
    def __init__(self):
        super().__init__('mqtt_bridge_node')

        # Declare parameters
        self.declare_parameter('mqtt_broker', '3925edbaea42456fa70bfb3b94db101b.s1.eu.hivemq.cloud')
        self.declare_parameter('mqtt_port', 8883)
        self.declare_parameter('mqtt_topic', 'lidar/clouddata')
        self.declare_parameter('mqtt_username', 'hivemq.webclient.1737813840747')
        self.declare_parameter('mqtt_password', 'OIg9nDcbC$172Z?Pl.,y')

        # Get parameters
        self.mqtt_broker = self.get_parameter('mqtt_broker').value
        self.mqtt_port = self.get_parameter('mqtt_port').value
        self.mqtt_topic = self.get_parameter('mqtt_topic').value
        self.mqtt_username = self.get_parameter('mqtt_username').value
        self.mqtt_password = self.get_parameter('mqtt_password').value

        # Initialize MQTT client
        self.mqtt_client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
        self.mqtt_client.username_pw_set(self.mqtt_username, self.mqtt_password)
        self.mqtt_client.tls_set()  # Enable TLS/SSL
        self.mqtt_client.tls_insecure_set(True)  # Allow self-signed certificates
        self.mqtt_client.connect(self.mqtt_broker, self.mqtt_port, 60)
        self.mqtt_client.loop_start()

        # Subscribe to LiDAR point cloud topic
        self.subscription = self.create_subscription(
            PointCloud2,
            'unilidar/cloud',
            self.lidar_callback,
            10
        )
        self.subscription  # Prevent unused variable warning

    def lidar_callback(self, msg):
        """Callback for LiDAR point cloud data."""
        try:
            # Convert PointCloud2 message to a JSON-serializable format
            point_cloud_data = self.pointcloud2_to_dict(msg)

            # Split the data into chunks if necessary
            max_chunk_size = 1024 * 1024  # 1 MB (adjust as needed)
            chunks = self.split_into_chunks(point_cloud_data, max_chunk_size)

            # Publish each chunk to the MQTT broker
            for i, chunk in enumerate(chunks):
                payload = json.dumps({
                    "header": point_cloud_data["header"],
                    "fields": point_cloud_data["fields"],
                    "height": point_cloud_data["height"],
                    "width": point_cloud_data["width"],
                    "is_bigendian": point_cloud_data["is_bigendian"],
                    "point_step": point_cloud_data["point_step"],
                    "row_step": point_cloud_data["row_step"],
                    "data": base64.b64encode(chunk).decode('utf-8'),  # Encode binary data as Base64
                    "is_dense": point_cloud_data["is_dense"],
                    "chunk_index": i,
                    "total_chunks": len(chunks)
                })
                self.mqtt_client.publish(self.mqtt_topic, payload)
                self.get_logger().info(f"Published chunk {i + 1}/{len(chunks)} to MQTT topic: {self.mqtt_topic}")
        except Exception as e:
            self.get_logger().error(f"Error processing LiDAR data: {e}")

    def pointcloud2_to_dict(self, msg):
        """Convert a PointCloud2 message to a dictionary."""
        return {
            'header': {
                'stamp': {
                    'sec': msg.header.stamp.sec,
                    'nanosec': msg.header.stamp.nanosec
                },
                'frame_id': msg.header.frame_id
            },
            'height': msg.height,
            'width': msg.width,
            'fields': [{'name': f.name, 'offset': f.offset, 'datatype': f.datatype, 'count': f.count} for f in msg.fields],
            'is_bigendian': msg.is_bigendian,
            'point_step': msg.point_step,
            'row_step': msg.row_step,
            'data': msg.data,  # Keep as bytes for now
            'is_dense': msg.is_dense
        }

    def split_into_chunks(self, data, max_chunk_size):
        """Split the PointCloud2 data into smaller chunks."""
        data_bytes = data["data"]
        chunks = [data_bytes[i:i + max_chunk_size] for i in range(0, len(data_bytes), max_chunk_size)]
        return chunks

    def __del__(self):
        """Clean up MQTT client on destruction."""
        self.mqtt_client.loop_stop()
        self.mqtt_client.disconnect()

def main(args=None):
    rclpy.init(args=args)
    node = MQTTBridgeNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
