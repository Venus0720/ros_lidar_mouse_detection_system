import os
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    # Run unitree lidar
    lidar_node = Node(
        package='unitree_lidar_ros2',
        executable='unitree_lidar_ros2_node',
        name='unitree_lidar_ros2_node',
        output='screen',
        parameters=[
            {'port': '/dev/ttyUSB0'},
            {'rotate_yaw_bias': 0.0},
            {'range_scale': 0.001},
            {'range_bias': 0.0},
            {'range_max': 50.0},
            {'range_min': 0.0},
            {'cloud_frame': "unilidar_lidar"},
            {'cloud_topic': "unilidar/cloud"},
            {'cloud_scan_num': 200},
            {'imu_frame': "unilidar_imu"},
            {'imu_topic': "unilidar/imu"}
        ]
    )

    # Run MQTT bridge node
    mqtt_node = Node(
        package='unitree_lidar_ros2',
        executable='mqtt_bridge_node.py',  # Use the full filename with .py
        name='mqtt_bridge_node',
        output='screen',
        parameters=[
            {'mqtt_broker': "3925edbaea42456fa70bfb3b94db101b.s1.eu.hivemq.cloud"},
            {'mqtt_port': 8883},
            {'mqtt_topic': "lidar/clouddata"},
            {'mqtt_username': "hivemq.webclient.1737813840747"},
            {'mqtt_password': "OIg9nDcbC$172Z?Pl.,y"}
        ]
    )

    return LaunchDescription([lidar_node, mqtt_node])
