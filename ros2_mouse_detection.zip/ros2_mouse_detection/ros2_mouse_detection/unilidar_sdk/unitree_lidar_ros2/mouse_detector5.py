import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2
import sensor_msgs_py.point_cloud2 as pc2
import numpy as np
from datetime import datetime, timedelta
from sklearn.cluster import DBSCAN
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point, Quaternion
from rclpy.duration import Duration

class UniLidarSubscriber(Node):

    def __init__(self):
        super().__init__('unilidar_subscriber')
        self.subscription = self.create_subscription(
            PointCloud2,
            '/unilidar/cloud',
            self.cloud_callback,
            10)
        self.subscription  # prevent unused variable warning
        
        self.marker_publisher = self.create_publisher(MarkerArray, '/mouse_markers', 10)
        
        self.last_minute = datetime.now().replace(second=0, microsecond=0)
        self.mouse_count = 0
        self.previous_points = None
        self.total_points_processed = 0
        self.frames_processed = 0
        
        self.tracked_objects = {}
        self.object_id_counter = 0

        # 參數設置
        self.movement_threshold = 0.01  # 3cm
        self.min_moving_points = 10
        self.min_cluster_points = 10
        self.mouse_size_range = {
            'min': [0.05, 0.05, 0.05],
            'max': [0.25, 0.25, 0.25]
        }
        self.significant_movement = 0.02  # 2cm
        self.consecutive_detections_for_confirmation = 1  # 連續檢測次數以確認為老鼠
        self.max_frames_without_detection = 10  # 最大允許未檢測到的幀數

    def cloud_callback(self, msg):
        current_time = datetime.now()
        
        try:
            pc = pc2.read_points(msg, field_names=("x", "y", "z", "intensity"), skip_nans=True)
            np_points = np.array(list(pc))
            xyz = np.array([np_points['x'], np_points['y'], np_points['z']]).T
            
            self.total_points_processed += xyz.shape[0]
            self.frames_processed += 1

            if self.previous_points is not None and xyz.shape == self.previous_points.shape:
                diff = np.abs(xyz - self.previous_points)
                moving_points = np.sum(diff > self.movement_threshold, axis=1)
                
                if np.sum(moving_points) > self.min_moving_points:
                    moving_xyz = xyz[moving_points > 0]
                    
                    clustering = DBSCAN(eps=0.1, min_samples=20).fit(moving_xyz)
                    labels = clustering.labels_
                    
                    current_objects = {}
                    
                    for label in set(labels):
                        if label == -1:  # Skip noise
                            continue
                        
                        cluster_points = moving_xyz[labels == label]
                        size = np.max(cluster_points, axis=0) - np.min(cluster_points, axis=0)
                        center = np.mean(cluster_points, axis=0)
                        
                        is_mouse_sized = all(self.mouse_size_range['min'][i] < size[i] < self.mouse_size_range['max'][i] for i in range(3))
                        has_enough_points = cluster_points.shape[0] >= self.min_cluster_points
                        
                        if is_mouse_sized and has_enough_points:
                            object_id = self.find_nearest_object(center)
                            if object_id is None:
                                object_id = self.object_id_counter
                                self.object_id_counter += 1
                                self.tracked_objects[object_id] = {
                                    'center': center,
                                    'size': size,
                                    'last_seen': current_time,
                                    'first_seen': current_time,
                                    'point_count': cluster_points.shape[0],
                                    'consecutive_detections': 1,
                                    'status': 'potential',
                                    'height': center[2]  # 記錄高度信息
                                }
                                self.get_logger().info(f'檢測到潛在老鼠 (ID: {object_id}):')
                                self.get_logger().info(f'   - 點數: {cluster_points.shape[0]}')
                                self.get_logger().info(f'   - 尺寸 (m): {size}')
                                self.get_logger().info(f'   - 位置 (x,y,z): {center}')
                                self.get_logger().info(f'   - 高度 (m): {center[2]}')
                            else:
                                obj = self.tracked_objects[object_id]
                                prev_center = obj['center']
                                obj['center'] = center
                                obj['size'] = size
                                obj['last_seen'] = current_time
                                obj['point_count'] = cluster_points.shape[0]
                                obj['consecutive_detections'] += 1
                                obj['height'] = center[2]  # 更新高度信息
                                
                                if obj['status'] == 'potential' and obj['consecutive_detections'] >= self.consecutive_detections_for_confirmation:
                                    obj['status'] = 'confirmed'
                                    self.get_logger().info(f'🐭! 確認為老鼠 (ID: {object_id})')
                                    self.mouse_count += 1
                                
                                movement = np.linalg.norm(center - prev_center)
                                if movement > self.significant_movement:
                                    self.get_logger().info(f'🐭 老鼠 (ID: {object_id}) 移動了 {movement:.2f}m')
                                    self.get_logger().info(f'   - 新位置 (x,y,z): {center}')
                                    self.get_logger().info(f'   - 新高度 (m): {center[2]}')
                            
                            current_objects[object_id] = self.tracked_objects[object_id]
                    
                    self.update_tracked_objects(current_objects, current_time)
                    self.publish_markers(current_objects)

            self.previous_points = xyz

            if current_time - self.last_minute >= timedelta(minutes=1):
                self.report_minute_stats(current_time)

        except Exception as e:
            self.get_logger().error(f'處理點雲數據時出錯: {str(e)}')

    def find_nearest_object(self, center, max_distance=0.2):
        for obj_id, obj_data in self.tracked_objects.items():
            distance = np.linalg.norm(obj_data['center'] - center)
            if distance < max_distance:
                return obj_id
        return None

    def update_tracked_objects(self, current_objects, current_time):
        objects_to_remove = []
        for obj_id, obj_data in self.tracked_objects.items():
            if obj_id not in current_objects:
                obj_data['consecutive_detections'] = 0
                time_since_last_seen = (current_time - obj_data['last_seen']).total_seconds()
                frames_since_last_seen = int(time_since_last_seen * 10)  # 假設10Hz的幀率
                if frames_since_last_seen > self.max_frames_without_detection:
                    objects_to_remove.append(obj_id)
                    tracking_duration = (obj_data['last_seen'] - obj_data['first_seen']).total_seconds()
                    self.get_logger().info(f'物體 (ID: {obj_id}, 狀態: {obj_data["status"]}) 消失，總跟蹤時間: {tracking_duration:.2f} 秒')

        for obj_id in objects_to_remove:
            del self.tracked_objects[obj_id]

    def publish_markers(self, current_objects):
        marker_array = MarkerArray()
        
        for obj_id, obj_data in current_objects.items():
            marker = Marker()
            marker.header.frame_id = "unilidar_link"
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.ns = "mouse_objects"
            marker.id = obj_id
            marker.type = Marker.CUBE
            marker.action = Marker.ADD
            
            marker.pose.position = Point(x=float(obj_data['center'][0]),
                                         y=float(obj_data['center'][1]),
                                         z=float(obj_data['center'][2]))
            marker.pose.orientation = Quaternion(x=0.0, y=0.0, z=0.0, w=1.0)
            
            marker.scale.x = float(obj_data['size'][0])
            marker.scale.y = float(obj_data['size'][1])
            marker.scale.z = float(obj_data['size'][2])
            
            if obj_data['status'] == 'potential':
                marker.color.r = 1.0
                marker.color.g = 1.0
                marker.color.b = 0.0
            else:  # confirmed
                marker.color.r = 1.0
                marker.color.g = 0.0
                marker.color.b = 0.0
            marker.color.a = 0.5
            
            marker.lifetime = Duration(seconds=0.5).to_msg()
            
            marker_array.markers.append(marker)
        
        self.marker_publisher.publish(marker_array)

    def report_minute_stats(self, current_time):
        avg_points_per_frame = self.total_points_processed / self.frames_processed if self.frames_processed > 0 else 0
        potential_mice = sum(1 for obj in self.tracked_objects.values() if obj['status'] == 'potential')
        confirmed_mice = sum(1 for obj in self.tracked_objects.values() if obj['status'] == 'confirmed')
        
        self.get_logger().info(f'⏰ 每分鐘報告:')
        self.get_logger().info(f'   - 過去一分鐘新確認的老鼠數量: {self.mouse_count}')
        self.get_logger().info(f'   - 當前潛在老鼠數量: {potential_mice}')
        self.get_logger().info(f'   - 當前確認老鼠數量: {confirmed_mice}')
        self.get_logger().info(f'   - 處理 {self.frames_processed} 幀數據')
        self.get_logger().info(f'   - 平均每幀 {avg_points_per_frame:.2f} 個點')
        self.get_logger().info(f'   - 當前跟蹤物體總數: {len(self.tracked_objects)}')
        
        # 報告不同高度範圍的老鼠數量
        height_ranges = {
            '低於0.5m': 0,
            '0.5m到1m': 0,
            '1m到2m': 0,
            '高於2m': 0
        }
        for obj in self.tracked_objects.values():
            height = obj['height']
            if height < 0.5:
                height_ranges['低於0.5m'] += 1
            elif 0.5 <= height < 1:
                height_ranges['0.5m到1m'] += 1
            elif 1 <= height < 2:
                height_ranges['1m到2m'] += 1
            else:
                height_ranges['高於2m'] += 1
        
        self.get_logger().info(f'   - 不同高度範圍的老鼠數量:')
        for range_name, count in height_ranges.items():
            self.get_logger().info(f'     * {range_name}: {count}')
        
        self.mouse_count = 0
        self.total_points_processed = 0
        self.frames_processed = 0
        self.last_minute = current_time.replace(second=0, microsecond=0)

def main(args=None):
    rclpy.init(args=args)
    unilidar_subscriber = UniLidarSubscriber()
    rclpy.spin(unilidar_subscriber)
    unilidar_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
