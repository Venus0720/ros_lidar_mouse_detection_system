import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2
import sensor_msgs_py.point_cloud2 as pc2
import numpy as np
from datetime import datetime, timedelta

class UniLidarSubscriber(Node):

    def __init__(self):
        super().__init__('unilidar_subscriber')
        self.subscription = self.create_subscription(
            PointCloud2,
            '/unilidar/cloud',
            self.cloud_callback,
            10)
        self.subscription  # prevent unused variable warning
        
        self.last_minute = datetime.now().replace(second=0, microsecond=0)
        self.mouse_count = 0
        self.previous_points = None
        self.total_points_processed = 0
        self.frames_processed = 0
        self.potential_mouse = False
        self.mouse_tracking_time = None
        self.mouse_disappeared_time = None

    def cloud_callback(self, msg):
        current_time = datetime.now()
        
        try:
            pc = pc2.read_points(msg, field_names=("x", "y", "z", "intensity"), skip_nans=True)
            np_points = np.array(list(pc))
            xyz = np.array([np_points['x'], np_points['y'], np_points['z']]).T
            
            self.total_points_processed += xyz.shape[0]
            self.frames_processed += 1

            if self.previous_points is not None and xyz.shape == self.previous_points.shape:
                diff = np.abs(xyz - self.previous_points)
                moving_points = np.sum(diff > 0.01, axis=1)  # 降低閾值以檢測更小的移動
                
                if np.sum(moving_points) > 50 and np.sum(moving_points) < 200:  # 調整範圍以匹配老鼠大小
                    if not self.potential_mouse:
                        self.potential_mouse = True
                        self.mouse_tracking_time = current_time
                        self.get_logger().info('🐭 潛在老鼠檢測到!')
                elif self.potential_mouse:
                    if (current_time - self.mouse_tracking_time).total_seconds() > 3:  # 如果老鼠持續出現超過3秒
                        if self.mouse_disappeared_time is None:
                            self.mouse_disappeared_time = current_time
                    elif self.mouse_disappeared_time is not None:
                        if (current_time - self.mouse_disappeared_time).total_seconds() > 5:  # 如果老鼠消失超過5秒
                            self.mouse_count += 1
                            self.get_logger().info(f'🐭 確認老鼠! 總計: {self.mouse_count}')
                            self.potential_mouse = False
                            self.mouse_tracking_time = None
                            self.mouse_disappeared_time = None
                    else:
                        self.mouse_disappeared_time = None

            self.previous_points = xyz

            if current_time - self.last_minute >= timedelta(minutes=1):
                avg_points_per_frame = self.total_points_processed / self.frames_processed if self.frames_processed > 0 else 0
                self.get_logger().info(f'⏰ 每分鐘報告:')
                self.get_logger().info(f'   - 在過去的一分鐘內檢測到 {self.mouse_count} 隻老鼠')
                self.get_logger().info(f'   - 處理了 {self.frames_processed} 幀數據')
                self.get_logger().info(f'   - 平均每幀 {avg_points_per_frame:.2f} 個點')
                self.mouse_count = 0
                self.total_points_processed = 0
                self.frames_processed = 0
                self.last_minute = current_time.replace(second=0, microsecond=0)

        except Exception as e:
            self.get_logger().error(f'處理點雲數據時出錯: {str(e)}')

def main(args=None):
    rclpy.init(args=args)
    unilidar_subscriber = UniLidarSubscriber()
    rclpy.spin(unilidar_subscriber)
    unilidar_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
