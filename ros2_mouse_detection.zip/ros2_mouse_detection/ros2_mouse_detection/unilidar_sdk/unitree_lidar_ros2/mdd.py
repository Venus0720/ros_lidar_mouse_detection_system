import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2
import sensor_msgs_py.point_cloud2 as pc2
import numpy as np
from datetime import datetime
import os
import struct
from pathlib import Path
from scipy.spatial import cKDTree

class PointCloudMapper(Node):
    def _init_(self):
        super()._init_('pointcloud_mapper')
        
        # 創建訂閱者
        self.subscription = self.create_subscription(
            PointCloud2,
            '/unilidar/cloud',  # 您的點雲話題名稱
            self.cloud_callback,
            10)
        
        # 初始化參數
        self.accumulated_points = []
        self.frame_count = 0
        self.max_frames = 100  # 收集100幀來建立地圖
        self.grid_size = 0.05  # 5cm的網格大小
        
        # 使用當前目錄下的 maps 資料夾
        self.map_save_path = Path.cwd() / 'lidar_maps'
        
        # 確保保存目錄存在
        try:
            self.map_save_path.mkdir(parents=True, exist_ok=True)
            self.get_logger().info(f"地圖將保存在: {self.map_save_path}")
        except Exception as e:
            # 如果創建目錄失敗，使用用戶的主目錄
            self.map_save_path = Path.home() / 'lidar_maps'
            self.map_save_path.mkdir(parents=True, exist_ok=True)
            self.get_logger().info(f"使用備用目錄: {self.map_save_path}")
        
        self.get_logger().info("開始收集點雲數據來建立地圖...")

    def cloud_callback(self, msg):
        """
        處理接收到的點雲數據
        """
        try:
            # 將ROS點雲消息轉換為numpy數組
            pc = pc2.read_points(msg, field_names=("x", "y", "z"), skip_nans=True)
            points = np.array(list(pc))
            
            if len(points) == 0:
                self.get_logger().warn("收到空的點雲數據")
                return
                
            # 添加到累積點雲中
            self.accumulated_points.append(points)
            self.frame_count += 1
            
            self.get_logger().info(f'收集到第 {self.frame_count}/{self.max_frames} 幀點雲數據')
            
            # 當收集足夠的幀數時，處理並保存地圖
            if self.frame_count >= self.max_frames:
                self.process_and_save_map()
                
        except Exception as e:
            self.get_logger().error(f'處理點雲數據時出錯: {str(e)}')

    def grid_downsample(self, points, grid_size):
        """
        使用網格下採樣來減少點雲密度
        """
        try:
            # 計算網格索引
            grid_indices = (points // grid_size).astype(int)
            
            # 創建唯一網格的字典
            grid_dict = {}
            for i, point in enumerate(points):
                idx = tuple(grid_indices[i])
                if idx not in grid_dict:
                    grid_dict[idx] = point
            
            # 返回下採樣後的點
            return np.array(list(grid_dict.values()))
        except Exception as e:
            self.get_logger().error(f'下採樣時出錯: {str(e)}')
            return points

    def remove_outliers(self, points, k=20, std_ratio=2.0):
        """
        移除離群點
        k: 鄰近點數量
        std_ratio: 標準差倍數閾值
        """
        try:
            # 計算每個點到其最近鄰的平均距離
            tree = cKDTree(points)
            distances, _ = tree.query(points, k=k)
            mean_distances = np.mean(distances, axis=1)
            
            # 計算距離的均值和標準差
            global_mean = np.mean(mean_distances)
            global_std = np.std(mean_distances)
            
            # 移除離群點
            mask = mean_distances < (global_mean + std_ratio * global_std)
            return points[mask]
        except Exception as e:
            self.get_logger().error(f'移除離群點時出錯: {str(e)}')
            return points

    def save_to_ply(self, points, filename):
        """
        保存點雲為PLY格式
        """
        try:
            with open(filename, 'wb') as f:
                # 寫入PLY頭部
                f.write(b"ply\n")
                f.write(b"format binary_little_endian 1.0\n")
                f.write(f"element vertex {len(points)}\n".encode())
                f.write(b"property float x\n")
                f.write(b"property float y\n")
                f.write(b"property float z\n")
                f.write(b"end_header\n")
                
                # 寫入點數據
                for point in points:
                    f.write(struct.pack('<fff', point[0], point[1], point[2]))
            
            self.get_logger().info(f'成功保存PLY文件: {filename}')
        except Exception as e:
            self.get_logger().error(f'保存PLY文件時出錯: {str(e)}')

    def process_and_save_map(self):
        """
        處理並保存地圖
        """
        try:
            # 合併所有點雲
            all_points = np.vstack(self.accumulated_points)
            initial_points = len(all_points)
            
            self.get_logger().info(f'開始處理點雲，初始點數: {initial_points}')
            
            # 下採樣
            downsampled_points = self.grid_downsample(all_points, self.grid_size)
            points_after_downsample = len(downsampled_points)
            
            # 移除離群點
            filtered_points = self.remove_outliers(downsampled_points)
            final_points = len(filtered_points)
            
            # 保存處理後的點雲地圖
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            map_filename = self.map_save_path / f'lidar_map_{timestamp}.ply'
            self.save_to_ply(filtered_points, str(map_filename))
            
            # 保存為numpy格式（便於後續處理）
            np_filename = self.map_save_path / f'lidar_map_{timestamp}.npy'
            np.save(str(np_filename), filtered_points)
            
            # 計算並輸出地圖統計信息
            min_coords = np.min(filtered_points, axis=0)
            max_coords = np.max(filtered_points, axis=0)
            dimensions = max_coords - min_coords
            
            self.get_logger().info("\n=== 地圖處理完成 ===")
            self.get_logger().info(f"初始點數: {initial_points}")
            self.get_logger().info(f"下採樣後點數: {points_after_downsample}")
            self.get_logger().info(f"最終點數: {final_points}")
            self.get_logger().info(f"地圖檔案: {map_filename}")
            self.get_logger().info(f"NumPy檔案: {np_filename}")
            self.get_logger().info("地圖尺寸 (米):")
            self.get_logger().info(f"  X: {dimensions[0]:.2f}")
            self.get_logger().info(f"  Y: {dimensions[1]:.2f}")
            self.get_logger().info(f"  Z: {dimensions[2]:.2f}")
            
            # 重置累積數據，為下一次地圖建立做準備
            self.accumulated_points = []
            self.frame_count = 0
            
        except Exception as e:
            self.get_logger().error(f'處理和保存地圖時出錯: {str(e)}')

def main(args=None):
    try:
        rclpy.init(args=args)
        mapper = PointCloudMapper()
        rclpy.spin(mapper)
    except Exception as e:
        print(f"程序執行出錯: {str(e)}")
    finally:
        if 'mapper' in locals():
            mapper.destroy_node()
        rclpy.shutdown()

if __name__ == '_main_':
    main()
