#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2
import sensor_msgs_py.point_cloud2 as pc2
import numpy as np
from sklearn.cluster import DBSCAN
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point, Quaternion
from rclpy.duration import Duration

class MouseDetector(Node):

    def __init__(self):
        super().__init__('mouse_detector')
        self.subscription = self.create_subscription(
            PointCloud2,
            '/unilidar/cloud',
            self.cloud_callback,
            10)
        self.marker_publisher = self.create_publisher(MarkerArray, '/mouse_markers', 10)
        
        self.previous_points = None
        self.tracked_objects = {}
        self.object_id_counter = 0

        # 參數設置
        self.movement_threshold = 0.03  # 3cm
        self.min_moving_points = 30
        self.min_cluster_points = 30
        self.mouse_size_range = {
            'min': [0.05, 0.05, 0.05],
            'max': [0.22, 0.22, 0.22]
        }
        self.significant_movement = 0.05  # 5cm
        self.consecutive_detections_for_confirmation = 5
        self.max_frames_without_detection = 10
        self.min_speed = 0.05  # m/s
        self.min_total_distance = 0.2  # m
        self.min_movement_for_detection = 0.05  # 5cm

        # 統計
        self.mouse_count = 0
        self.potential_mice_per_minute = 0
        self.total_points_processed = 0
        self.frames_processed = 0
        self.last_minute = self.get_clock().now()

        self.get_logger().info('Mouse Detector initialized')

    def cloud_callback(self, msg):
        current_time = self.get_clock().now()
        
        try:
            pc = pc2.read_points(msg, field_names=("x", "y", "z"), skip_nans=True)
            xyz = np.array([(x, y, z) for x, y, z in pc])
            
            self.total_points_processed += xyz.shape[0]
            self.frames_processed += 1

            if self.previous_points is not None and xyz.shape == self.previous_points.shape:
                diff = np.abs(xyz - self.previous_points)
                moving_points = np.sum(diff > self.movement_threshold, axis=1)
                
                if np.sum(moving_points) > self.min_moving_points:
                    moving_xyz = xyz[moving_points > 0]
                    
                    clustering = DBSCAN(eps=0.1, min_samples=20).fit(moving_xyz)
                    labels = clustering.labels_
                    
                    current_objects = {}
                    
                    for label in set(labels):
                        if label == -1:  # Skip noise
                            continue
                        
                        cluster_points = moving_xyz[labels == label]
                        size = np.max(cluster_points, axis=0) - np.min(cluster_points, axis=0)
                        center = np.mean(cluster_points, axis=0)
                        
                        is_mouse_sized = all(self.mouse_size_range['min'][i] < size[i] < self.mouse_size_range['max'][i] for i in range(3))
                        has_enough_points = cluster_points.shape[0] >= self.min_cluster_points
                        
                        if is_mouse_sized and has_enough_points:
                            object_id = self.find_nearest_object(center)
                            if object_id is None:
                                new_object = {
                                    'center': center,
                                    'size': size,
                                    'last_seen': current_time,
                                    'first_seen': current_time,
                                    'point_count': cluster_points.shape[0],
                                    'consecutive_detections': 1,
                                    'status': 'tracking',  # 初始狀態為 'tracking'
                                    'height': center[2],
                                    'last_position': center,
                                    'last_time': current_time,
                                    'total_distance': 0.0,
                                    'speed': 0.0,
                                    'positions': [center],  # 存儲位置歷史
                                    'times': [current_time.nanoseconds / 1e9]  # 存儲時間歷史
                                }
                                object_id = self.object_id_counter
                                self.object_id_counter += 1
                                self.tracked_objects[object_id] = new_object
                            else:
                                obj = self.tracked_objects[object_id]
                                time_diff = (current_time - obj['last_time']).nanoseconds / 1e9
                                distance = np.linalg.norm(center - obj['last_position'])
                                speed = distance / time_diff if time_diff > 0 else 0

                                obj['center'] = center
                                obj['size'] = size
                                obj['last_seen'] = current_time
                                obj['point_count'] = cluster_points.shape[0]
                                obj['consecutive_detections'] += 1
                                obj['height'] = center[2]
                                obj['last_position'] = center
                                obj['last_time'] = current_time
                                obj['total_distance'] += distance
                                obj['speed'] = speed
                                obj['positions'].append(center)
                                obj['times'].append(current_time.nanoseconds / 1e9)

                                # 檢查是否滿足 potential mouse 的條件
                                if obj['status'] == 'tracking' and len(obj['positions']) >= 5:
                                    total_time = obj['times'][-1] - obj['times'][0]
                                    total_distance = np.linalg.norm(obj['positions'][-1] - obj['positions'][0])
                                    avg_speed = total_distance / total_time if total_time > 0 else 0

                                    if (avg_speed >= self.min_speed and 
                                        total_distance >= self.min_total_distance and
                                        obj['consecutive_detections'] >= self.consecutive_detections_for_confirmation):
                                        obj['status'] = 'potential'
                                        self.get_logger().info(f'🐭? Potential mouse detected (ID: {object_id})')
                                        self.potential_mice_per_minute += 1

                                # 檢查是否滿足 confirmed mouse 的條件
                                if (obj['status'] == 'potential' and 
                                    obj['speed'] >= self.min_speed and
                                    obj['total_distance'] >= self.min_total_distance):
                                    obj['status'] = 'confirmed'
                                    self.get_logger().info(f'🐭! Mouse confirmed (ID: {object_id})')
                                    self.mouse_count += 1

                                if speed > self.significant_movement:
                                    self.get_logger().info(f'🐭 Mouse (ID: {object_id}) moved {distance:.2f}m')
                            
                            if object_id is not None:
                                current_objects[object_id] = self.tracked_objects[object_id]
                    
                    self.update_tracked_objects(current_objects, current_time)
                    self.publish_markers(current_objects)

            self.previous_points = xyz

            if (current_time - self.last_minute).nanoseconds / 1e9 >= 60:
                self.report_minute_stats(current_time)

        except Exception as e:
            self.get_logger().error(f'Error processing point cloud data: {str(e)}')

    def find_nearest_object(self, center, max_distance=0.2):
        for obj_id, obj_data in self.tracked_objects.items():
            distance = np.linalg.norm(obj_data['center'] - center)
            if distance < max_distance:
                return obj_id
        return None

    def update_tracked_objects(self, current_objects, current_time):
        objects_to_remove = []
        for obj_id, obj_data in self.tracked_objects.items():
            if obj_id not in current_objects:
                obj_data['consecutive_detections'] = 0
                time_since_last_seen = (current_time - obj_data['last_seen']).nanoseconds / 1e9
                if time_since_last_seen > self.max_frames_without_detection / 10:
                    objects_to_remove.append(obj_id)
                    tracking_duration = (obj_data['last_seen'] - obj_data['first_seen']).nanoseconds / 1e9
                    self.get_logger().info(f'Object (ID: {obj_id}, Status: {obj_data["status"]}) disappeared, total tracking time: {tracking_duration:.2f} seconds')

        for obj_id in objects_to_remove:
            del self.tracked_objects[obj_id]

    def publish_markers(self, current_objects):
        marker_array = MarkerArray()
        
        for obj_id, obj_data in current_objects.items():
            marker = Marker()
            marker.header.frame_id = "unilidar_link"
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.ns = "mouse_objects"
            marker.id = obj_id
            marker.type = Marker.CUBE
            marker.action = Marker.ADD
            
            marker.pose.position = Point(x=float(obj_data['center'][0]),
                                         y=float(obj_data['center'][1]),
                                         z=float(obj_data['center'][2]))
            marker.pose.orientation = Quaternion(x=0.0, y=0.0, z=0.0, w=1.0)
            
            marker.scale.x = float(obj_data['size'][0])
            marker.scale.y = float(obj_data['size'][1])
            marker.scale.z = float(obj_data['size'][2])
            
            if obj_data['status'] == 'tracking':
                marker.color.r = 0.0
                marker.color.g = 1.0
                marker.color.b = 1.0
            elif obj_data['status'] == 'potential':
                marker.color.r = 1.0
                marker.color.g = 1.0
                marker.color.b = 0.0
            else:  # confirmed
                marker.color.r = 1.0
                marker.color.g = 0.0
                marker.color.b = 0.0
            marker.color.a = 0.5
            
            marker.lifetime = Duration(seconds=0.5).to_msg()
            
            marker_array.markers.append(marker)
        
        self.marker_publisher.publish(marker_array)

    def report_minute_stats(self, current_time):
        avg_points_per_frame = self.total_points_processed / self.frames_processed if self.frames_processed > 0 else 0
        tracking_objects = sum(1 for obj in self.tracked_objects.values() if obj['status'] == 'tracking')
        potential_mice = sum(1 for obj in self.tracked_objects.values() if obj['status'] == 'potential')
        confirmed_mice = sum(1 for obj in self.tracked_objects.values() if obj['status'] == 'confirmed')
        
        self.get_logger().info(f'⏰ Minute Report:')
        self.get_logger().info(f'   - New potential mice detected in the last minute: {self.potential_mice_per_minute}')
        self.get_logger().info(f'   - New confirmed mice in the last minute: {self.mouse_count}')
        self.get_logger().info(f'   - Current tracking objects: {tracking_objects}')
        self.get_logger().info(f'   - Current potential mice: {potential_mice}')
        self.get_logger().info(f'   - Current confirmed mice: {confirmed_mice}')
        self.get_logger().info(f'   - Processed {self.frames_processed} frames')
        self.get_logger().info(f'   - Average {avg_points_per_frame:.2f} points per frame')
        self.get_logger().info(f'   - Total tracked objects: {len(self.tracked_objects)}')
        
        height_ranges = {
            'Below 0.5m': 0,
            '0.5m to 1m': 0,
            '1m to 2m': 0,
            'Above 2m': 0
        }
        for obj in self.tracked_objects.values():
            height = obj['height']
            if height < 0.5:
                height_ranges['Below 0.5m'] += 1
            elif 0.5 <= height < 1:
                height_ranges['0.5m to 1m'] += 1
            elif 1 <= height < 2:
                height_ranges['1m to 2m'] += 1
            else:
                height_ranges['Above 2m'] += 1
        
        self.get_logger().info(f'   - Objects count by height range:')
        for range_name, count in height_ranges.items():
            self.get_logger().info(f'     * {range_name}: {count}')
        
        self.mouse_count = 0
        self.potential_mice_per_minute = 0
        self.total_points_processed = 0
        self.frames_processed = 0
        self.last_minute = current_time

def main(args=None):
    rclpy.init(args=args)
    mouse_detector = MouseDetector()
    rclpy.spin(mouse_detector)
    mouse_detector.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
